# CSC 225 — Sorting Robot Lottery: Results

**Random seed:** ________  
**Algorithm 1:** ________  
**Algorithm 2:** ________

The driver generates **50 random lists of 100 integers each**. Both algorithms receive the same list for each run. Paste the 50 comparison counts from the program for each algorithm below (rather than filling in a 50-row table).

**Algorithm 1 counts (50 runs):**

```text

```

**Algorithm 2 counts (50 runs):**

```text

```

| Statistic | Algorithm 1 | Algorithm 2 |
|---|---:|---:|
| Average | | |
| Median | | |
| Minimum | | |
| Maximum | | |
| Population standard deviation | | |
| Q1 (lower quartile) | | |
| Q3 (upper quartile) | | |
| Five-number summary (min, Q1, median, Q3, max) | | |

Quartiles use the **median-of-halves** convention (for 50 values, split the sorted counts into two halves of 25).

**Which algorithm used fewer comparisons across the 50 runs?**


**One interesting observation:**
